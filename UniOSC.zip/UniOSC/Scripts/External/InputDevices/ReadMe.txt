These components need some third party Assets from other vendors.
Please look at the source code to get the information you need to get the appropriate Asset. 